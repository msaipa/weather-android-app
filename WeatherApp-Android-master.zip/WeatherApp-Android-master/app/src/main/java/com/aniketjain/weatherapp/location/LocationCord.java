package com.aniketjain.weatherapp.location;

public class LocationCord {
    public static String lat = "";
    public static String lon = "";
        public final static String API_KEY = "0bc14881636d2234e8c17736a470535f";
//    public final static String API_KEY = "eeb8b40367eee691683e5a079e2fa695";
}

